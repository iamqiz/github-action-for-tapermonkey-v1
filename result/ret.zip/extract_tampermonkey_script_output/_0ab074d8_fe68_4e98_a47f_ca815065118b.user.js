// ==UserScript==
// @name         New Userscript111
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  try to take over the world!
// @author       You
// @match        https://github.com/gay0hub/test-github-action-22-10-20
// @icon         https://www.google.com/s2/favicons?sz=64&domain=github.com
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    // Your code here...
    //New Userscript111
    console.log("dsads")
})();